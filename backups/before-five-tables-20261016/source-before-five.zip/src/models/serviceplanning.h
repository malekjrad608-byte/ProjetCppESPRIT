#pragma once
#include "service.h"
#include <QList>
#include <QSet>

namespace ServicePlanning {
struct Appointment {
    int serviceId=0; // Zero denotes an independent task, which is edited in Employés.
    int employeeId=0;
    QString title,client,status;
    QDateTime start,finish;
};
QList<Appointment> appointments(QString *error);
// False also means that availability could not be checked: fail closed.
bool available(int employee,const QDateTime &start,const QDateTime &finish,int excludedService,QString *error);
QDate weekStart(const QDate &date);
QDateTime end(const Service &service);
QSet<int> conflictingServices(const QList<Service> &services);
QList<Service> inWeek(const QList<Service> &services,const QDate &date,int employee=0,bool cancelled=false);
}
