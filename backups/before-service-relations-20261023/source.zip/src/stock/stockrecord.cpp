#include "stockrecord.h"
#include "../database/oracleconnection.h"
#include <QCryptographicHash>
#include <QMap>
#include <QSet>
#include <QSqlError>
#include <QSqlQuery>
bool StockRecord::afficher(QVector<StockRecord> *items, qint64 *revision,
                           QString *error) {
  Rows rows;
  if (!readRows(&rows, revision, error))
    return false;
  items->clear();
  for (const auto &r : rows) {
    StockRecord item;
    item.lot = r[0].toString();
    item.article = r[1].toString();
    item.category = r[2].toString();
    item.quantity = r[3].toInt();
    item.unit = r[4].toString();
    item.threshold = r[5].toInt();
    item.expiry = QDate::fromString(r[6].toString(), Qt::ISODate);
    item.localId = r[7].toInt();
    items->append(item);
  }
  return true;
}
bool StockRecord::enregistrer(const QVector<StockRecord> &items,
                              qint64 *revision, QString *error) {
  Rows rows;
  QSet<QString> lots;
  for (const auto &r : items) {
    if (r.lot.trimmed().isEmpty() || r.article.trimmed().isEmpty() ||
        r.quantity < 0 || r.threshold < 0 || r.localId <= 0 ||
        !r.expiry.isValid() || lots.contains(r.lot)) {
      *error = "Vérifiez le lot unique, l’article, la quantité, le seuil, "
               "l’échéance et le local obligatoire.";
      return false;
    }
    lots.insert(r.lot);
    rows.append({r.lot, r.article, r.category, r.quantity, r.unit, r.threshold,
                 r.expiry.toString(Qt::ISODate), r.localId});
  }
  return saveRows(rows, revision, error);
}

bool StockRecord::loadRows(Rows *rows, QString *error) {
  QSqlQuery q(OracleConnection::database());
  const auto fields = QStringList{"lot",  "article",   "category", "quantity",
                                  "unit", "threshold", "expiry",   "id_local"};
  if (!(q.prepare("SELECT " + fields.join(',') + " FROM " +
                  QStringLiteral("stock_lots") + " ORDER BY " + fields[0]) &&
        q.exec())) {
    *error = q.lastError().text();
    return false;
  }
  rows->clear();
  while (q.next()) {
    QVariantList row;
    for (int i = 0; i < fields.size(); ++i)
      row << q.value(i);
    *rows << row;
  }
  return true;
}
qint64 StockRecord::rowsVersion(const Rows &rows) {
  QMap<QString, QVariantList> ordered;
  for (const auto &row : rows)
    ordered.insert(row[0].toString(), row);
  QByteArray bytes;
  for (const auto &row : ordered)
    for (const auto &value : row) {
      const auto s = value.toString().toUtf8();
      bytes += QByteArray::number(s.size()) + ':' + s;
    }
  const auto hash = QCryptographicHash::hash(bytes, QCryptographicHash::Sha256);
  quint64 result = 0;
  for (int i = 0; i < 8; ++i)
    result = (result << 8) | quint8(hash[i]);
  return qint64((result & 0x7fffffffffffffffULL) | 1);
}
bool StockRecord::readRows(Rows *rows, qint64 *revision, QString *error) {
  if (!loadRows(rows, error))
    return false;
  *revision = rowsVersion(*rows);
  error->clear();
  return true;
}
bool StockRecord::saveRows(const Rows &rows, qint64 *revision, QString *error) {
  const auto fields = QStringList{"lot",  "article",   "category", "quantity",
                                  "unit", "threshold", "expiry",   "id_local"};
  QSet<QString> keys;
  for (const auto &row : rows) {
    if (row.size() != fields.size() || row[0].toString().trimmed().isEmpty() ||
        keys.contains(row[0].toString())) {
      *error = "Identifiant vide ou en double.";
      return false;
    }
    if (row.last().toInt() <= 0) {
      *error = "Choisissez le local de chaque lot.";
      return false;
    }
    keys.insert(row[0].toString());
  }
  auto db = OracleConnection::database();
  if (!db.transaction()) {
    *error = db.lastError().text();
    return false;
  }
  auto fail = [&](QString message) {
    db.rollback();
    *error = message.section(QChar(0), 0, 0);
    return false;
  };
  QSqlQuery q(db);
  if (!(q.prepare("LOCK TABLE " + QStringLiteral("stock_lots") +
                  " IN EXCLUSIVE MODE WAIT 5") &&
        q.exec()))
    return fail(q.lastError().text());
  Rows beforeRows;
  if (!loadRows(&beforeRows, error))
    return fail(*error);
  if (rowsVersion(beforeRows) != *revision)
    return fail("Ces données ont été modifiées par une autre session. "
                "Actualisez avant de réessayer.");
  QMap<QString, QVariantList> old;
  for (const auto &row : beforeRows)
    old.insert(row[0].toString(), row);
  for (auto it = old.cbegin(); it != old.cend(); ++it)
    if (!keys.contains(it.key())) {
      q.prepare("DELETE FROM " + QStringLiteral("stock_lots") + " WHERE " +
                fields[0] + "=?");
      q.addBindValue(it.value()[0]);
      if (!q.exec())
        return fail(q.lastError().text().contains("02292")
                        ? "Ce local contient encore du stock. Réaffectez ses "
                          "lots avant suppression."
                        : q.lastError().text());
    }
  for (const auto &row : rows) {
    const auto before = old.value(row[0].toString());
    bool changed = before.isEmpty();
    for (int i = 0; !changed && i < fields.size(); ++i)
      changed = before[i].toString() != row[i].toString();
    if (!changed)
      continue;
    if (before.isEmpty()) {
      QStringList marks;
      for (int i = 0; i < fields.size(); ++i)
        marks << "?";
      q.prepare("INSERT INTO " + QStringLiteral("stock_lots") + "(" +
                fields.join(',') + ") VALUES(" + marks.join(',') + ")");
      for (const auto &v : row)
        q.addBindValue(v);
    } else {
      QStringList assignments;
      for (int i = 1; i < fields.size(); ++i)
        assignments << fields[i] + "=?";
      q.prepare("UPDATE " + QStringLiteral("stock_lots") + " SET " +
                assignments.join(',') + " WHERE " + fields[0] + "=?");
      for (int i = 1; i < fields.size(); ++i)
        q.addBindValue(row[i]);
      q.addBindValue(row[0]);
    }
    if (!q.exec())
      return fail(q.lastError().text());
  }
  Rows saved;
  if (!loadRows(&saved, error))
    return fail(*error);
  if (!db.commit())
    return fail(db.lastError().text());
  *revision = rowsVersion(saved);
  error->clear();
  return true;
}
