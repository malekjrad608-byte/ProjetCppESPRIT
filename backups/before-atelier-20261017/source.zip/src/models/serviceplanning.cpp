#include "serviceplanning.h"
#include <algorithm>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include "../database/oracleconnection.h"

namespace ServicePlanning {
QList<Appointment> appointments(QString *error) {
    error->clear();QList<Appointment> result;
    QSqlQuery q(QSqlDatabase::database("aniworld-services"));
    if(!q.exec(OracleConnection::isOracle()?"SELECT s.id,e.id,s.name,s.clientName,s.status,s.dateTime,s.duration FROM services s JOIN employes e ON e.id_service=s.id":"SELECT id,id_employe,name,clientName,status,dateTime,duration FROM services")) {
        *error="Lecture du planning impossible : "+q.lastError().text();return {};
    }
    while(q.next()) {
        Appointment a;a.serviceId=q.value(0).toInt();a.employeeId=q.value(1).toInt();
        a.title=QString("SRV-%1 · ").arg(a.serviceId,3,10,QChar('0'))+q.value(2).toString();
        a.client=q.value(3).toString();a.status=q.value(4).toString();
        a.start=QDateTime::fromString(q.value(5).toString(),Qt::ISODate);a.finish=a.start.addSecs(q.value(6).toInt()*60);
        if(!a.start.isValid() || a.finish<=a.start){*error="Un service possède un créneau invalide. Corrigez sa date et sa durée.";return {};}
        result<<a;
    }
    if(!OracleConnection::isOracle()) {
    if(!q.exec("SELECT id,responsable_id,titre,debut,fin FROM planning_affectations")) {
        *error="Lecture des tâches impossible : "+q.lastError().text();return {};
    }
    while(q.next()) {
        Appointment a;a.employeeId=q.value(1).toInt();a.title=QString("Tâche #%1 · ").arg(q.value(0).toInt())+q.value(2).toString();a.status="Tâche";
        a.start=QDateTime::fromString(q.value(3).toString(),"yyyy-MM-dd HH:mm:ss");
        a.finish=QDateTime::fromString(q.value(4).toString(),"yyyy-MM-dd HH:mm:ss");
        if(!a.start.isValid() || !a.finish.isValid() || a.finish<=a.start){*error="Une tâche possède un créneau invalide. Corrigez son planning dans Employés.";return {};}
        result<<a;
    }
    }
    std::sort(result.begin(),result.end(),[](const Appointment &a,const Appointment &b){return a.start==b.start?a.title<b.title:a.start<b.start;});
    return result;
}
bool available(int employee,const QDateTime &start,const QDateTime &finish,int excludedService,QString *error) {
    error->clear();if(employee<=0)return true;
    if(!start.isValid() || !finish.isValid() || finish<=start){*error="Créneau invalide.";return false;}
    const auto entries=appointments(error);if(!error->isEmpty())return false;
    for(const auto &a:entries) {
        if(a.employeeId!=employee || a.status=="Annulé" || (excludedService>0 && a.serviceId==excludedService))continue;
        if(start<a.finish && a.start<finish) {
            *error=QString("Affectation impossible : cet employé est déjà occupé par %1, du %2 au %3. Choisissez un autre horaire ou un autre employé.")
                .arg(a.title,a.start.toString("dd/MM/yyyy HH:mm"),a.finish.toString("dd/MM/yyyy HH:mm"));return false;
        }
    }
    return true;
}
QDate weekStart(const QDate &date) { return date.addDays(1-date.dayOfWeek()); }
QDateTime end(const Service &service) { return service.dateTime.addSecs(qint64(service.duration)*60); }
QSet<int> conflictingServices(const QList<Service> &services) {
    QSet<int> result;
    for(int i=0;i<services.size();++i) {
        const auto &a=services[i];
        if(a.employeeId<=0 || a.status=="Annulé" || !a.dateTime.isValid() || a.duration<=0) continue;
        for(int j=i+1;j<services.size();++j) {
            const auto &b=services[j];
            if(b.employeeId!=a.employeeId || b.status=="Annulé" || !b.dateTime.isValid() || b.duration<=0) continue;
            if(a.dateTime<end(b) && b.dateTime<end(a)) {result.insert(a.id);result.insert(b.id);}
        }
    }
    return result;
}
QList<Service> inWeek(const QList<Service> &services,const QDate &date,int employee,bool cancelled) {
    const auto monday=weekStart(date);
    const QDateTime start(monday,QTime(0,0)),finish(monday.addDays(7),QTime(0,0));
    QList<Service> result;
    for(const auto &s:services) {
        if(!s.dateTime.isValid() || s.dateTime>=finish || end(s)<=start) continue;
        if(!cancelled && s.status=="Annulé") continue;
        if(employee>0 && s.employeeId!=employee) continue;
        if(employee==-1 && s.employeeId>0) continue;
        result<<s;
    }
    std::sort(result.begin(),result.end(),[](const Service &a,const Service &b){return a.dateTime==b.dateTime?a.id<b.id:a.dateTime<b.dateTime;});
    return result;
}
}
