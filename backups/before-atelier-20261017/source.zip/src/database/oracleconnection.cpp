#include "oracleconnection.h"
#include <QSettings>
#include <QStandardPaths>
#include <QFileInfo>
#include <QFile>
#include <QSqlError>
#include <QSqlRecord>
#include <QSet>

namespace OracleConnection {
QString defaultConfigPath() { return QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation)+"/oracle.ini"; }
bool configured() { QSettings s(defaultConfigPath(),QSettings::IniFormat); return s.value("oracle/enabled",false).toBool(); }
bool isOracle() { return QSqlDatabase::database("aniworld-services",false).driverName()=="QODBC"; }
bool open(QSqlDatabase &db,QString *error,const QString &configPath) {
    const QString path=configPath.isEmpty()?defaultConfigPath():configPath;
    QSettings s(path,QSettings::IniFormat);
    const auto bin=s.value("oracle/home").toString()+"/bin";
    qputenv("PATH",bin.toLocal8Bit()+";"+qgetenv("PATH"));
    db=QSqlDatabase::addDatabase("QODBC","aniworld-services");
    // Paramètres de l'atelier : source ODBC 64 bits et compte Oracle RAWAND.
    db.setDatabaseName("Source_Projet2A18"); // Nom de la source de données ODBC
    db.setUserName("rawand");               // Utilisateur Oracle
    db.setPassword("rawand123123");         // Mot de passe de cet utilisateur
    db.setConnectOptions("SQL_ATTR_LOGIN_TIMEOUT=5");
    const bool opened=db.open();
    if(!opened) { *error=db.lastError().text(); return false; }
    QSqlQuery q(db);
    if(!q.exec("SELECT COUNT(*) FROM user_tables") || !q.next() || q.value(0).toInt()!=5) {
        *error="Le schéma Oracle doit contenir exactement les cinq tables métier.";db.close();return false;
    }
    if(!q.exec("SELECT COUNT(*) FROM user_tab_columns WHERE (table_name IN ('EMPLOYES','LOCAUX') AND column_name='ID_SERVICE') OR (table_name='MEDICAL_RECORDS' AND column_name='ID_EMPLOYE')") || !q.next() || q.value(0).toInt()!=3) {
        *error="Migration vers le modèle à cinq tables nécessaire.";db.close();return false;
    }
    error->clear();return true;
}
qint64 insertedId(const QSqlQuery &query,const QString &table) {
    if(!isOracle()) return query.lastInsertId().toLongLong();
    // Whitelist identifiers; CURRVAL is private to this session, unlike MAX(id).
    if(!QStringList{"services","medical_records"}.contains(table)) return 0;
    QSqlQuery id(QSqlDatabase::database("aniworld-services"));
    return id.exec("SELECT "+table+"_seq.CURRVAL FROM dual") && id.next()?id.value(0).toLongLong():0;
}
bool migrateLocal(const QString &,QString *error) {
    *error="L’import de l’ancien modèle est désactivé dans le schéma à cinq tables.";return false;
}
}
