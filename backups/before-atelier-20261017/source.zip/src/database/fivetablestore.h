#pragma once
#include "../models/service.h"
#include <QList>
#include <QPair>
#include <QVariant>

// Persistence rules for the teacher's five-entity relational model.
namespace FiveTableStore {
bool saveService(const Service &service,bool update,int *insertedId,QString *error);
bool saveEmployee(int id,int serviceId,const QList<QVariant> &values,QString *error);
int employeeService(int employeeId);
QString invoiceStatus(int serviceId);
QString friendlyError(const QString &message);
}
