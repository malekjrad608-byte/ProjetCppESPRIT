#pragma once
#include <QString>
#include <QDateTime>
#include <QList>
class QSqlQueryModel;
class QObject;

class Service {
public:
    Service() = default;
    bool ajouter(QString *error);
    bool modifier(QString *error) const;
    static bool supprimer(int id, QString *error);
    static QList<Service> afficherListe(QString *error);
    static QSqlQueryModel *afficher(QObject *parent = nullptr);

    int id = 0;
    int localId = 0;
    int employeeId = 0;
    int clientId = 0;
    QString newEmployeeNom;
    QString newEmployeePrenom;
    QString name;
    QString description;
    QString responsible;
    QString clientName;
    QString invoiceNumber;
    QDateTime invoiceDate;
    QString category = QStringLiteral("Soins & bien-être");
    QDateTime dateTime = QDateTime::currentDateTime();
    QString status = QStringLiteral("Planifié");
    int duration = 30;
    double price = 0;
private:
    bool enregistrer(bool update, int *insertedId, QString *error) const;
};
