#include "oracleconnection.h"
#include "connection.h"
#include <QSettings>
#include <QStandardPaths>
#include <QFileInfo>
#include <QFile>
#include <QSqlError>
#include <QSqlRecord>
#include <QSet>

namespace OracleConnection {
QString defaultConfigPath() { return QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation)+"/oracle.ini"; }
bool configured() { QSettings s(defaultConfigPath(),QSettings::IniFormat); return s.value("oracle/enabled",false).toBool(); }
QSqlDatabase database() {
    // The original Connection class owns Qt's default ODBC connection.
    // A closed Oracle handle may remain registered while a demo/test uses SQLite.
    return QSqlDatabase::contains("aniworld-services")
        ? QSqlDatabase::database("aniworld-services",false)
        : QSqlDatabase::database(QSqlDatabase::defaultConnection,false);
}
bool isOracle() { return database().driverName()=="QODBC"; }
bool open(QSqlDatabase &db,QString *error,const QString &configPath) {
    const QString path=configPath.isEmpty()?defaultConfigPath():configPath;
    QSettings s(path,QSettings::IniFormat);
    const auto bin=s.value("oracle/home").toString()+"/bin";
    qputenv("PATH",bin.toLocal8Bit()+";"+qgetenv("PATH"));
    // Keep the teacher's connection.cpp/.h unchanged: only its three DB parameters differ.
    Connection &connection = Connection::createInstance();
    const bool opened=connection.createConnection();
    db=QSqlDatabase::database(QSqlDatabase::defaultConnection,false);
    if(!opened) { *error=db.lastError().text(); return false; }
    QSqlQuery q(db);
    if(!(q.prepare("SELECT COUNT(*) FROM user_tables") && q.exec()) || !q.next() || q.value(0).toInt()!=5) {
        *error="Le schéma Oracle doit contenir exactement les cinq tables métier.";db.close();return false;
    }
    if(!(q.prepare("SELECT COUNT(*) FROM user_tab_columns WHERE (table_name IN ('EMPLOYES','LOCAUX') AND column_name='ID_SERVICE') OR (table_name='MEDICAL_RECORDS' AND column_name='ID_EMPLOYE')") && q.exec()) || !q.next() || q.value(0).toInt()!=3) {
        *error="Migration vers le modèle à cinq tables nécessaire.";db.close();return false;
    }
    error->clear();return true;
}
qint64 insertedId(const QSqlQuery &query,const QString &table) {
    if(!isOracle()) return query.lastInsertId().toLongLong();
    // Whitelist identifiers; CURRVAL is private to this session, unlike MAX(id).
    if(!QStringList{"services","medical_records"}.contains(table)) return 0;
    QSqlQuery id(OracleConnection::database());
    return (id.prepare("SELECT "+table+"_seq.CURRVAL FROM dual") && id.exec()) && id.next()?id.value(0).toLongLong():0;
}
bool migrateLocal(const QString &,QString *error) {
    *error="L’import de l’ancien modèle est désactivé dans le schéma à cinq tables.";return false;
}
}

QString OracleConnection::diagnostic(QString *error) {
    QSqlQuery query(OracleConnection::database());
    query.prepare("SELECT USER,SYS_CONTEXT('USERENV','CON_NAME') FROM dual");
    if(!query.exec() || !query.next()){*error=query.lastError().text();return {};}
    QString report="Connexion Qt QODBC : "+query.value(0).toString()+" / "+query.value(1).toString()+"\n";
    for(const QString &table:{QString("services"),QString("employes"),QString("medical_records"),QString("locaux"),QString("stock_lots")}) {
        query.prepare("SELECT COUNT(*) FROM "+table);
        if(!query.exec() || !query.next()){*error=query.lastError().text();return {};}
        report+=table+" : "+query.value(0).toString()+"\n";
    }
    error->clear();return report;
}
