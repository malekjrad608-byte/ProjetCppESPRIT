#pragma once
#include <QSqlDatabase>
#include <QSqlQuery>

namespace OracleConnection {
QString defaultConfigPath();
bool configured();
// Active application handle: teacher Singleton in Oracle, isolated SQLite in demo/tests.
QSqlDatabase database();
bool open(QSqlDatabase &db, QString *error, const QString &configPath = {});
bool isOracle();
QString diagnostic(QString *error);
qint64 insertedId(const QSqlQuery &query, const QString &table);
bool migrateLocal(const QString &path, QString *error);
}
