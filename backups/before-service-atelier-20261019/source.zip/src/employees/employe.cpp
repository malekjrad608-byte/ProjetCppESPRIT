#include "employe.h"
#include "../models/employeequeries.h"
#include "../models/fivetablestore.h"
#include "../database/oracleconnection.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QRegularExpression>
#include <cmath>

QList<Employe> Employe::afficher(const QString &filter,const QString &sort,const QString &job,const QString &status,QString *error) {
    auto rows=EmployeeQueries::list(filter,sort,job,status);
    if(error)*error=rows.lastError().text();
    QList<Employe> result;
    while(rows.next()) {
        Employe e;
        e.m_id=rows.value(0).toInt(); e.m_nom=rows.value(1).toString(); e.m_prenom=rows.value(2).toString();
        e.m_courriel=rows.value(3).toString(); e.m_telephone=rows.value(4).toString(); e.m_poste=rows.value(5).toString();
        e.m_dateEmbauche=QDate::fromString(rows.value(6).toString(),Qt::ISODate); e.m_disponible=rows.value(7).toInt()!=0;
        e.m_chargeHebdo=rows.value(8).toDouble(); e.m_dispoHebdo=rows.value(9).toDouble(); e.m_competences=rows.value(10).toString();
        result.append(e);
    }
    return result;
}
bool Employe::enregistrer(bool update,QString *error) const {
    error->clear();
    if(m_nom.trimmed().isEmpty() || m_prenom.trimmed().isEmpty() || m_nom.size()>120 || m_prenom.size()>120 || !m_dateEmbauche.isValid()) {
        *error="Nom et prénom obligatoires (120 caractères maximum), avec une date d’embauche valide."; return false;
    }
    if(!std::isfinite(m_chargeHebdo) || !std::isfinite(m_dispoHebdo) || m_chargeHebdo<0 || m_chargeHebdo>60 || m_dispoHebdo<0 || m_dispoHebdo>60) {
        *error="Les heures doivent être comprises entre 0 et 60."; return false;
    }
    if(!m_courriel.isEmpty() && !QRegularExpression(R"(^[^\s@]+@[^\s@]+\.[^\s@]+$)").match(m_courriel).hasMatch()) {
        *error="Saisissez une adresse courriel valide."; return false;
    }
    const QVariantList values={m_nom.trimmed(),m_prenom.trimmed(),m_courriel.trimmed(),m_telephone.trimmed(),m_poste,m_dateEmbauche.toString(Qt::ISODate),m_disponible?1:0,m_chargeHebdo,m_dispoHebdo,m_competences.trimmed()};
    if(OracleConnection::isOracle()) return FiveTableStore::saveEmployee(update?m_id:0,m_serviceId,values,error);
    QSqlQuery query(OracleConnection::database());
    query.prepare(update?"UPDATE employes SET nom=?,prenom=?,courriel=?,telephone=?,poste=?,date_embauche=?,disponible=?,charge_hebdo=?,dispo_hebdo=?,competences=? WHERE id=?":"INSERT INTO employes(nom,prenom,courriel,telephone,poste,date_embauche,disponible,charge_hebdo,dispo_hebdo,competences) VALUES(?,?,?,?,?,?,?,?,?,?)");
    for(const auto &value:values)query.addBindValue(value);
    if(update)query.addBindValue(m_id);
    if(!query.exec()){*error=query.lastError().text();return false;}
    if(query.numRowsAffected()!=1){*error="Employé introuvable. Actualisez la liste.";return false;}
    return true;
}
bool Employe::ajouter(QString *error) {
    if(!enregistrer(false,error))return false;
    QSqlQuery query(OracleConnection::database());
    query.prepare(OracleConnection::isOracle()?"SELECT employes_seq.CURRVAL FROM dual":"SELECT last_insert_rowid()");
    if(query.exec() && query.next())m_id=query.value(0).toInt();
    return true;
}
bool Employe::modifier(QString *error) const {return enregistrer(true,error);}
bool Employe::supprimer(int id,QString *error) {
    QSqlQuery query(OracleConnection::database());
    query.prepare("DELETE FROM employes WHERE id=?"); query.addBindValue(id);
    if(!query.exec()){*error=FiveTableStore::friendlyError(query.lastError().text());return false;}
    if(query.numRowsAffected()!=1){*error="Employé introuvable. Actualisez la liste.";return false;}
    error->clear();return true;
}
bool Employe::basculerDisponibilite(int id,QString *error) {
    QSqlQuery query(OracleConnection::database());
    query.prepare("UPDATE employes SET disponible=CASE WHEN disponible=1 THEN 0 ELSE 1 END WHERE id=?"); query.addBindValue(id);
    if(!query.exec()){*error=query.lastError().text();return false;}
    if(query.numRowsAffected()!=1){*error="Employé introuvable. Actualisez la liste.";return false;}
    error->clear();return true;
}

Employe::Employe() {}

double Employe::tauxCharge() const
{
    if (m_dispoHebdo <= 0) return 0.0;
    return m_chargeHebdo / m_dispoHebdo;
}

bool Employe::depasseSeuil(double seuil) const
{
    return tauxCharge() > seuil;
}
