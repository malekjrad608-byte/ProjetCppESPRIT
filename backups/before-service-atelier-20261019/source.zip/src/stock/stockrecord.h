#pragma once
#include <QDate>
#include <QString>
#include <QVector>
class StockRecord {
public:
    QString article;
    QString category;
    QString lot;
    int quantity = 0;
    QString unit;
    int threshold = 1;
    QDate expiry;
    int localId = 0;
    static bool afficher(QVector<StockRecord> *items,qint64 *revision,QString *error);
    static bool enregistrer(const QVector<StockRecord> &items,qint64 *revision,QString *error);
};

