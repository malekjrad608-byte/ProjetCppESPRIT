#include "stockrecord.h"
#include "../models/oraclecollection.h"
#include <QSet>
bool StockRecord::afficher(QVector<StockRecord> *items,qint64 *revision,QString *error) {
    OracleCollection::Rows rows;
    if(!OracleCollection::read("stock",&rows,revision,error))return false;
    items->clear();
    for(const auto &r:rows) {
        StockRecord item;item.lot=r[0].toString();item.article=r[1].toString();item.category=r[2].toString();
        item.quantity=r[3].toInt();item.unit=r[4].toString();item.threshold=r[5].toInt();item.expiry=QDate::fromString(r[6].toString(),Qt::ISODate);item.localId=r[7].toInt();
        items->append(item);
    }
    return true;
}
bool StockRecord::enregistrer(const QVector<StockRecord> &items,qint64 *revision,QString *error) {
    OracleCollection::Rows rows;QSet<QString> lots;
    for(const auto &r:items) {
        if(r.lot.trimmed().isEmpty() || r.article.trimmed().isEmpty() || r.quantity<0 || r.threshold<0 || r.localId<=0 || !r.expiry.isValid() || lots.contains(r.lot)) {
            *error="Vérifiez le lot unique, l’article, la quantité, le seuil, l’échéance et le local obligatoire.";return false;
        }
        lots.insert(r.lot);
        rows.append({r.lot,r.article,r.category,r.quantity,r.unit,r.threshold,r.expiry.toString(Qt::ISODate),r.localId});
    }
    return OracleCollection::save("stock",rows,revision,error);
}
