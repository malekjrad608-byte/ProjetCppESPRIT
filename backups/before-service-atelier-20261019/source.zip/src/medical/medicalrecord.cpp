#include "medicalrecord.h"

MedicalRecord::MedicalRecord()
{
    animal.age = 0;
    medical.weight = 0.0;
}

MedicalRecord::MedicalRecord(const AnimalInfo& animalInfo, const MedicalInfo& medicalInfo)
    : animal(animalInfo), medical(medicalInfo)
{
}

QString MedicalRecord::getFullName() const
{
    return animal.name;
}

QString MedicalRecord::getVaccinationStatus() const
{
    return medical.vaccinationStatus;
}

bool MedicalRecord::operator==(const MedicalRecord& other) const
{
    return medical.recordId == other.medical.recordId;
}

#include "medicalstore.h"
bool MedicalRecord::ajouter(QString *error) { if(storageId!=0){*error="Ce dossier existe déjà.";return false;}return MedicalStore::save(*this,error); }
bool MedicalRecord::modifier(QString *error) { if(storageId<=0){*error="Dossier non enregistré.";return false;}return MedicalStore::save(*this,error); }
QVector<MedicalRecord> MedicalRecord::afficher(QString *error) { return MedicalStore::all(error); }
bool MedicalRecord::supprimer(qint64 id,QString *error) { return MedicalStore::remove(id,error); }
