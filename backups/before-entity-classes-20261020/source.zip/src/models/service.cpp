#include "service.h"
#include "../database/oracleconnection.h"
#include "fivetablestore.h"
#include "serviceplanning.h"
#include <QScopedPointer>
#include <QSqlError>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QSqlRecord>
#include <cmath>
namespace {
QVariant nullableId(int id) {
    return id > 0 ? QVariant(id) : QVariant(QMetaType(QMetaType::Int));
}
} // namespace
// Constructeur parametre : memes etapes que Etudiant dans l'atelier.
Service::Service(int id, const QString &name, const QString &clientName, const QString &category,
                 const QDateTime &dateTime, const QString &status, int duration, double price) {
    this->id = id;
    this->name = name;
    this->clientName = clientName;
    this->category = category;
    this->dateTime = dateTime;
    this->status = status;
    this->duration = duration;
    this->price = price;
}

QList<Service> Service::afficherListe(QString *error) {
    QList<Service> result;
    QScopedPointer<QSqlQueryModel> model(Service().afficher());
    if (model->lastError().isValid()) {
        *error = model->lastError().text();
        return result;
    }
    while (model->canFetchMore())
        model->fetchMore();
    error->clear();
    for (int row = 0; row < model->rowCount(); ++row) {
        const auto query = model->record(row);
        Service s;
        s.id = query.value(0).toInt();
        s.name = query.value(1).toString();
        s.description = query.value(2).toString();
        s.responsible = query.value(3).toString();
        s.category = query.value(4).toString();
        s.dateTime = QDateTime::fromString(query.value(5).toString(), Qt::ISODate);
        s.status = query.value(6).toString();
        s.duration = query.value(7).toInt();
        s.price = query.value(8).toDouble();
        s.clientName = query.value(9).toString();
        s.invoiceNumber = query.value(10).toString();
        s.invoiceDate = QDateTime::fromString(query.value(11).toString(), Qt::ISODate);
        s.localId = query.value(12).toInt();
        s.employeeId = query.value(13).toInt();
        s.clientId = query.value(14).toInt();
        result.append(s);
    }
    return result;
}
bool Service::enregistrer(bool update, int *insertedId, QString *error) const {
    const Service &s = *this;
    if (s.name.trimmed().isEmpty() || s.name.trimmed().size() > 120 || !s.dateTime.isValid()) {
        *error = "Vérifiez le nom et la date du service.";
        return false;
    }
    if (s.clientName.size() > 120 || s.description.size() > 5000 || !std::isfinite(s.price) || s.price < 0 ||
        s.price > 99999.99) {
        *error = "Vérifiez le client, le détail et le tarif de la prestation.";
        return false;
    }
    if (s.duration < 5 || s.duration > 1440 ||
        !QStringList{"Planifié", "En cours", "Terminé", "Annulé"}.contains(s.status) ||
        s.category.trimmed().isEmpty()) {
        *error = "Vérifiez la catégorie, le statut et la durée (5 à 1440 minutes).";
        return false;
    }
    if (s.status != "Annulé" && !ServicePlanning::available(s.employeeId, s.dateTime, ServicePlanning::end(s),
                                                            update ? s.id : 0, error))
        return false;
    if (OracleConnection::isOracle())
        return enregistrerOracle(update, insertedId, error);
    QSqlQuery query(OracleConnection::database());
    query.prepare(
        update ? "UPDATE services SET "
                 "name=:name,description=:description,responsible=:responsible,category=:category,dateTime=:"
                 "datetime,status=:status,duration=:duration,price=:price,clientName=:clientName,id_local=:"
                 "id_local,id_employe=:id_employe,id_client=:id_client WHERE id=:id"
               : "INSERT INTO "
                 "services(name,description,responsible,category,dateTime,status,duration,price,clientName,"
                 "id_local,id_employe,id_client) "
                 "VALUES(:name,:description,:responsible,:category,:datetime,:status,:duration,:price,:"
                 "clientName,:id_local,:id_employe,:id_client)");
    query.bindValue(":name", s.name.trimmed());
    query.bindValue(":description", s.description.isNull() ? QStringLiteral("") : s.description.trimmed());
    query.bindValue(":responsible", s.responsible.isNull() ? QStringLiteral("") : s.responsible.trimmed());
    query.bindValue(":category", s.category);
    query.bindValue(":datetime", s.dateTime.toString(Qt::ISODate));
    query.bindValue(":status", s.status);
    query.bindValue(":duration", s.duration);
    query.bindValue(":price", s.price);
    query.bindValue(":clientName", s.clientName.isNull() ? QStringLiteral("") : s.clientName.trimmed());
    query.bindValue(":id_local", nullableId(s.localId));
    query.bindValue(":id_employe", nullableId(s.employeeId));
    query.bindValue(":id_client", nullableId(s.clientId));
    if (update)
        query.bindValue(":id", s.id);
    if (!query.exec()) {
        const auto code = query.lastError().nativeErrorCode();
        *error =
            code.contains("20041")
                ? QStringLiteral("Cette facture a déjà été émise ou annulée. Ses informations sont "
                                 "conservées ; créez une nouvelle prestation pour corriger la facturation.")
                : query.lastError().text();
        if (code.contains("20051"))
            *error = "Affectation refusée : cet employé a déjà un service ou une tâche sur ce créneau. "
                     "Actualisez le planning et choisissez un autre horaire ou un autre employé.";
        return false;
    }
    if (update && query.numRowsAffected() != 1) {
        *error = "Ce service n'existe plus.";
        return false;
    }
    if (!update)
        *insertedId = int(OracleConnection::insertedId(query, "services"));
    error->clear();
    return true;
}
bool Service::ajouter() {
    int inserted = 0;
    // INSERT prepare/bindValue/exec dans enregistrer(), puis commit en mode Oracle.
    if (!enregistrer(false, &inserted, &m_error))
        return false;
    id = inserted;
    return true;
}
bool Service::ajouter(QString *error) {
    const bool test = ajouter();
    *error = m_error;
    return test;
}
bool Service::modifier(QString *error) const {
    int inserted = 0;
    return enregistrer(true, &inserted, error);
}
bool Service::supprimer(int id) {
    QSqlQuery query(OracleConnection::database());
    query.prepare("DELETE FROM services WHERE id=:id");
    query.bindValue(":id", id);
    if (!query.exec()) {
        m_error = OracleConnection::isOracle() ? FiveTableStore::friendlyError(query.lastError().text())
                                              : query.lastError().text();
        return false;
    }
    if (query.numRowsAffected() != 1) {
        m_error = "Ce service n'existe plus.";
        return false;
    }
    m_error.clear();
    return true;
}
bool Service::supprimer(int id, QString *error) {
    Service service;
    const bool test = service.supprimer(id);
    *error = service.lastError();
    return test;
}

QSqlQueryModel *Service::afficher(QObject *parent, const QList<int> *orderedIds) const {
    auto *model = new QSqlQueryModel(parent);
    QSqlQuery query(OracleConnection::database());
    QString sql = OracleConnection::isOracle()
                      ? "SELECT "
                        "id,name,description,responsible,category,dateTime,status,duration,price,clientName,"
                        "invoiceNumber,invoiceDate,0,id_employe,0 FROM services"
                      : "SELECT "
                        "id,name,description,responsible,category,dateTime,status,duration,price,clientName,"
                        "invoiceNumber,invoiceDate,id_local,id_employe,id_client FROM services";
    // La vue transmet uniquement les identifiants filtres, jamais du SQL.
    if (orderedIds) {
        if (orderedIds->isEmpty())
            sql += " WHERE 1=0";
        else {
            // Oracle accepte au plus 1000 valeurs dans chaque expression IN.
            QStringList groups;
            for (int first = 0; first < orderedIds->size(); first += 900) {
                QStringList placeholders;
                for (int i = first; i < qMin(first + 900, int(orderedIds->size())); ++i)
                    placeholders << "?";
                groups << "id IN (" + placeholders.join(',') + ")";
            }
            sql += " WHERE (" + groups.join(" OR ") + ") ORDER BY CASE id";
            for (int i = 0; i < orderedIds->size(); ++i)
                sql += " WHEN ? THEN " + QString::number(i);
            sql += " END";
        }
    } else
        sql += " ORDER BY dateTime DESC,id DESC";
    query.prepare(sql);
    if (orderedIds) {
        for (int value : *orderedIds)
            query.addBindValue(value);
        for (int value : *orderedIds)
            query.addBindValue(value);
    }
    query.exec();
    model->setQuery(std::move(query));
    const QStringList titles = {"ID",        "Service",      "Description",      "Référent",
                                "Catégorie", "Date / heure", "Statut",           "Durée",
                                "Tarif",     "Client",       "Facture",          "Date facture",
                                "Local",     "Employé",      "Client enregistré"};
    for (int i = 0; i < titles.size(); ++i)
        model->setHeaderData(i, Qt::Horizontal, titles[i]);
    return model;
}

bool Service::enregistrerOracle(bool update, int *insertedId, QString *error) const {
    const Service &s = *this;
    auto db = OracleConnection::database();
    const bool createEmployee = s.employeeId == -1;
    if (s.employeeId <= 0 && !createEmployee) {
        *error = "Choisissez un employé ou créez le premier employé du service.";
        return false;
    }
    if (createEmployee && (s.newEmployeeNom.trimmed().isEmpty() || s.newEmployeePrenom.trimmed().isEmpty())) {
        *error = "Nom et prénom du nouvel employé obligatoires.";
        return false;
    }
    if (!db.transaction()) {
        *error = db.lastError().text();
        return false;
    }
    auto fail = [&](QString message) {
        db.rollback();
        *error = FiveTableStore::friendlyError(message);
        return false;
    };
    const int id = update ? s.id : FiveTableStore::nextId("services_seq");
    const int employee = createEmployee ? FiveTableStore::nextId("employes_seq") : s.employeeId;
    if (id <= 0 || employee <= 0)
        return fail("Impossible de générer les identifiants.");
    QSqlQuery q(db);
    q.prepare(update ? "UPDATE services SET "
                       "name=:name,description=:description,responsible=:responsible,category=:category,"
                       "datetime=:datetime,status=:status,duration=:duration,price=:price,clientName=:"
                       "clientName,id_employe=:id_employe WHERE id=:id"
                     : "INSERT INTO "
                       "services(name,description,responsible,category,datetime,status,duration,price,"
                       "clientName,id_employe,id) "
                       "VALUES(:name,:description,:responsible,:category,:datetime,:status,:duration,:price,:"
                       "clientName,:id_employe,:id)");
    q.bindValue(":name", s.name.trimmed());
    q.bindValue(":description", s.description);
    q.bindValue(":responsible",
                createEmployee ? s.newEmployeeNom + " " + s.newEmployeePrenom : s.responsible);
    q.bindValue(":category", s.category);
    q.bindValue(":datetime", s.dateTime.toString(Qt::ISODate));
    q.bindValue(":status", s.status);
    q.bindValue(":duration", s.duration);
    q.bindValue(":price", s.price);
    q.bindValue(":clientName", s.clientName);
    q.bindValue(":id_employe", employee);
    q.bindValue(":id", id);
    if (!q.exec())
        return fail(q.lastError().text());
    if (q.numRowsAffected() != 1)
        return fail("Service introuvable.");
    if (createEmployee) {
        q.prepare("INSERT INTO employes(id,nom,prenom,id_service,date_embauche) VALUES(?,?,?,?,?)");
        q.addBindValue(employee);
        q.addBindValue(s.newEmployeeNom.trimmed());
        q.addBindValue(s.newEmployeePrenom.trimmed());
        q.addBindValue(id);
        q.addBindValue(QDate::currentDate().toString(Qt::ISODate));
        if (!q.exec())
            return fail(q.lastError().text());
    } else if (!FiveTableStore::moveEmployee(employee, id, error))
        return fail(*error);
    if (!db.commit())
        return fail(db.lastError().text());
    *insertedId = id;
    error->clear();
    return true;
}

bool Service::modifier() {
    return modifier(&m_error);
}
