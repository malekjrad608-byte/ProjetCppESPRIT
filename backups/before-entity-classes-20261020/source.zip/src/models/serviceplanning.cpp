#include "serviceplanning.h"
#include <algorithm>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include "../database/oracleconnection.h"

namespace ServicePlanning {
QList<Appointment> appointments(QString *error) {
    error->clear();QList<Appointment> result;
    QSqlQuery q(OracleConnection::database());
    if(!(q.prepare(OracleConnection::isOracle()?"SELECT s.id,e.id,s.name,s.clientName,s.status,s.dateTime,s.duration FROM services s JOIN employes e ON e.id_service=s.id":"SELECT id,id_employe,name,clientName,status,dateTime,duration FROM services") && q.exec())) {
        *error="Lecture du planning impossible : "+q.lastError().text();return {};
    }
    while(q.next()) {
        Appointment a;a.serviceId=q.value(0).toInt();a.employeeId=q.value(1).toInt();
        a.title=QString("SRV-%1 · ").arg(a.serviceId,3,10,QChar('0'))+q.value(2).toString();
        a.client=q.value(3).toString();a.status=q.value(4).toString();
        a.start=QDateTime::fromString(q.value(5).toString(),Qt::ISODate);a.finish=a.start.addSecs(q.value(6).toInt()*60);
        if(!a.start.isValid() || a.finish<=a.start){*error="Un service possède un créneau invalide. Corrigez sa date et sa durée.";return {};}
        result<<a;
    }
    if(!OracleConnection::isOracle()) {
    if(!(q.prepare("SELECT id,responsable_id,titre,debut,fin FROM planning_affectations") && q.exec())) {
        *error="Lecture des tâches impossible : "+q.lastError().text();return {};
    }
    while(q.next()) {
        Appointment a;a.employeeId=q.value(1).toInt();a.title=QString("Tâche #%1 · ").arg(q.value(0).toInt())+q.value(2).toString();a.status="Tâche";
        a.start=QDateTime::fromString(q.value(3).toString(),"yyyy-MM-dd HH:mm:ss");
        a.finish=QDateTime::fromString(q.value(4).toString(),"yyyy-MM-dd HH:mm:ss");
        if(!a.start.isValid() || !a.finish.isValid() || a.finish<=a.start){*error="Une tâche possède un créneau invalide. Corrigez son planning dans Employés.";return {};}
        result<<a;
    }
    }
    std::sort(result.begin(),result.end(),[](const Appointment &a,const Appointment &b){return a.start==b.start?a.title<b.title:a.start<b.start;});
    return result;
}
bool available(int employee,const QDateTime &start,const QDateTime &finish,int excludedService,QString *error) {
    error->clear();if(employee<=0)return true;
    if(!start.isValid() || !finish.isValid() || finish<=start){*error="Créneau invalide.";return false;}
    const auto entries=appointments(error);if(!error->isEmpty())return false;
    for(const auto &a:entries) {
        if(a.employeeId!=employee || a.status=="Annulé" || (excludedService>0 && a.serviceId==excludedService))continue;
        if(start<a.finish && a.start<finish) {
            *error=QString("Affectation impossible : cet employé est déjà occupé par %1, du %2 au %3. Choisissez un autre horaire ou un autre employé.")
                .arg(a.title,a.start.toString("dd/MM/yyyy HH:mm"),a.finish.toString("dd/MM/yyyy HH:mm"));return false;
        }
    }
    return true;
}
QDate weekStart(const QDate &date) { return date.addDays(1-date.dayOfWeek()); }
QDateTime end(const Service &service) { return service.getDateTime().addSecs(qint64(service.getDuration())*60); }
QSet<int> conflictingServices(const QList<Service> &services) {
    QSet<int> result;
    for(int i=0;i<services.size();++i) {
        const auto &a=services[i];
        if(a.getEmployeeId()<=0 || a.getStatus()=="Annulé" || !a.getDateTime().isValid() || a.getDuration()<=0) continue;
        for(int j=i+1;j<services.size();++j) {
            const auto &b=services[j];
            if(b.getEmployeeId()!=a.getEmployeeId() || b.getStatus()=="Annulé" || !b.getDateTime().isValid() || b.getDuration()<=0) continue;
            if(a.getDateTime()<end(b) && b.getDateTime()<end(a)) {result.insert(a.getId());result.insert(b.getId());}
        }
    }
    return result;
}
QList<Service> inWeek(const QList<Service> &services,const QDate &date,int employee,bool cancelled) {
    const auto monday=weekStart(date);
    const QDateTime start(monday,QTime(0,0)),finish(monday.addDays(7),QTime(0,0));
    QList<Service> result;
    for(const auto &s:services) {
        if(!s.getDateTime().isValid() || s.getDateTime()>=finish || end(s)<=start) continue;
        if(!cancelled && s.getStatus()=="Annulé") continue;
        if(employee>0 && s.getEmployeeId()!=employee) continue;
        if(employee==-1 && s.getEmployeeId()>0) continue;
        result<<s;
    }
    std::sort(result.begin(),result.end(),[](const Service &a,const Service &b){return a.getDateTime()==b.getDateTime()?a.getId()<b.getId():a.getDateTime()<b.getDateTime();});
    return result;
}
}
