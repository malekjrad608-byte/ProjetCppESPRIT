#include "../database/oracleconnection.h"
#include "fivetablestore.h"
#include "serviceplanning.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>

namespace FiveTableStore {
QSqlDatabase database(){return OracleConnection::database();}
int nextId(const QString &sequence){QSqlQuery q(database());if(!(q.prepare("SELECT "+sequence+".NEXTVAL FROM dual") && q.exec())||!q.next())return 0;return q.value(0).toInt();}
bool moveEmployee(int employee,int target,QString *error) {
    QSqlQuery q(database());q.prepare("SELECT id_service FROM employes WHERE id=? FOR UPDATE WAIT 5");q.addBindValue(employee);
    if(!q.exec()||!q.next()){*error="Employé introuvable ou occupé par une autre modification.";return false;}
    const int previous=q.value(0).toInt();q.finish();
    if(previous==target)return true;
    q.prepare("SELECT id FROM employes WHERE id_service=? AND id<>? ORDER BY id");q.addBindValue(previous);q.addBindValue(employee);
    if(!q.exec()||!q.next()){*error="Le service d’origine doit garder au moins un employé. Ajoutez-lui un autre employé avant cette réaffectation.";return false;}
    const int replacement=q.value(0).toInt();q.finish();
    q.prepare("UPDATE services SET id_employe=?,responsible=CASE WHEN invoice_status='BROUILLON' THEN (SELECT TRIM(nom||' '||prenom) FROM employes WHERE id=?) ELSE responsible END WHERE id=? AND id_employe=?");q.addBindValue(replacement);q.addBindValue(replacement);q.addBindValue(previous);q.addBindValue(employee);
    if(!q.exec()){*error=q.lastError().text();return false;}
    q.prepare("UPDATE employes SET id_service=? WHERE id=?");q.addBindValue(target);q.addBindValue(employee);
    if(!q.exec()){*error=q.lastError().text();return false;}return true;
}

QString friendlyError(const QString &s) {
    if(s.contains("20051"))return "Cet employé est déjà occupé sur ce créneau. Choisissez un autre horaire.";
    if(s.contains("20041"))return "La facture a déjà été émise. Ses informations sont conservées.";
    if(s.contains("FK_SERVICE_TEAM")||s.contains("FK_EMPLOYE_SERVICE"))return "Chaque service doit garder au moins un employé et chaque employé doit appartenir à un service.";
    if(s.contains("02292"))return "Cet élément est encore utilisé. Réaffectez ses éléments liés avant suppression.";
    return s.section(QChar(0),0,0);
}
int employeeService(int id){QSqlQuery q(database());q.prepare("SELECT id_service FROM employes WHERE id=?");q.addBindValue(id);return q.exec()&&q.next()?q.value(0).toInt():0;}
QString invoiceStatus(int id){QSqlQuery q(database());q.prepare("SELECT invoice_status FROM services WHERE id=?");q.addBindValue(id);return q.exec()&&q.next()?q.value(0).toString():QString();}
bool saveEmployee(int id,int service,const QList<QVariant> &values,QString *error) {
    if(service<=0){*error="Choisissez le service de cet employé.";return false;}
    auto db=database();if(!db.transaction()){*error=db.lastError().text();return false;}
    auto fail=[&](QString message){db.rollback();*error=friendlyError(message);return false;};
    if(id>0 && employeeService(id)!=service) {
        QSqlQuery slot(db);slot.prepare("SELECT datetime,duration FROM services WHERE id=?");slot.addBindValue(service);
        if(!slot.exec()||!slot.next())return fail("Service introuvable.");
        auto start=QDateTime::fromString(slot.value(0).toString(),Qt::ISODate);auto end=start.addSecs(slot.value(1).toInt()*60);slot.finish();
        if(!ServicePlanning::available(id,start,end,service,error))return fail(*error);
        if(!moveEmployee(id,service,error))return fail(*error);
    }
    QSqlQuery q(db);q.prepare(id>0?
        "UPDATE employes SET nom=?,prenom=?,courriel=?,telephone=?,poste=?,date_embauche=?,disponible=?,charge_hebdo=?,dispo_hebdo=?,competences=? WHERE id=?":
        "INSERT INTO employes(nom,prenom,courriel,telephone,poste,date_embauche,disponible,charge_hebdo,dispo_hebdo,competences,id_service) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
    for(const auto &v:values)q.addBindValue(v);
    q.addBindValue(id>0?id:service);
    if(!q.exec())return fail(q.lastError().text());
    if(id>0){
        q.prepare("UPDATE services SET responsible=? WHERE id_employe=? AND invoice_status='BROUILLON'");
        q.addBindValue(values[0].toString()+" "+values[1].toString());q.addBindValue(id);
        if(!q.exec())return fail(q.lastError().text());
    }
    if(!db.commit())return fail(db.lastError().text());
    error->clear();return true;
}
}
