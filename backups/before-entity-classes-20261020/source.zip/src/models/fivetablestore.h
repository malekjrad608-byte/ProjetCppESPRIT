#pragma once
#include "service.h"
#include <QList>
#include <QPair>
#include <QVariant>

// Persistence rules for the teacher's five-entity relational model.
namespace FiveTableStore {
int nextId(const QString &sequence);
bool moveEmployee(int employee, int target, QString *error);
bool saveEmployee(int id,int serviceId,const QList<QVariant> &values,QString *error);
int employeeService(int employeeId);
QString invoiceStatus(int serviceId);
QString friendlyError(const QString &message);
}
