from pathlib import Path
from html import escape
root=Path(__file__).resolve().parents[1]
out=root/'artifacts/atelier-crud-review/rapport-atelier.html'
rows=[
(1,'Titre, auteurs et année','Contexte','Atelier 3 CRUD, Soumaya Argoubi / Soumaya Nheri, 2025–2026.'),
(2,'Plan de l’atelier','Appliqué','GUI, séparation modèle–vue, entités C++, requêtes préparées et CRUD. Les notes interdisent aussi le SQL derrière les boutons.'),
(3,'Ajouter, supprimer et afficher un étudiant','Adapté au projet','Les opérations concernent les entités ANIWORLD. Aucune table ETUDIANT ajoutée : le modèle commun reste à cinq tables.'),
(4,'Partie interface','Conservé','Interface ANIWORLD existante ; la diapositive introduit la section.'),
(5,'Formulaire d’ajout','Modifié','Services → Ajouter affiche maintenant le formulaire dans la page, sans fenêtre modale séparée.'),
(6,'Liste des enregistrements','Conservé / complété','Affichage initial et filtres conservés. Service::afficher() fournit maintenant un QSqlQueryModel ; afficherListe() en extrait les entités pour les cartes et la liste existantes.'),
(7,'Suppression','Conservé','Action sur la sélection, avec confirmation. Pas de page entière réservée à la suppression, conformément à la remarque p.47.'),
(8,'Partie modèle–vue','Appliqué','Les widgets appellent les modèles et ne construisent plus de SQL.'),
(9,'Séparer données et interface','Corrigé','SQL retiré de GestionEmployes, ServicePlanningDialog, RelationChoices, LocalChoice et Invoice UI.'),
(10,'Aucune requête derrière un bouton','Corrigé','Contrôle statique sur 39 fichiers de vue : aucune requête SQL ni accès direct QSqlDatabase.'),
(11,'Responsabilités modèle/vue','Corrigé','EmployeeQueries, RelationModel, InvoiceModel et les entités assurent les accès aux données. Les vues affichent les résultats.'),
(12,'Signals et slots','Conservé','clicked déclenche les commandes ; servicesChanged et LocalRepository::changed actualisent les vues.'),
(13,'Interaction et rafraîchissement','Vérifié','Ajout/modification/suppression réussis rechargent la liste. Un échec conserve le formulaire et les valeurs saisies.'),
(14,'Partie classes C++','Appliqué','Les modèles sont distincts des classes QWidget/QDialog.'),
(15,'Ajouter une classe C++','Adapté au projet','Les classes métier existantes sont complétées ; création de StockRecord, EmployeeQueries, RelationModel et InvoiceModel.'),
(16,'Fichiers .h et .cpp','Ajouté','Nouveaux fichiers déclarés dans sources.pri et compilés dans l’application et les tests.'),
(17,'Entité, constructeurs, accesseurs et CRUD','Adapté au projet','Employe conserve ses attributs privés et accesseurs ; Service reçoit ajouter/modifier/supprimer/afficher. Les objets Service, Local, StockRecord et MedicalRecord conservent leurs champs de données existants pour compatibilité : ce n’est pas une copie textuelle de la classe Etudiant.'),
(18,'Implémentation dans le .cpp','Ajouté','service.cpp auparavant presque vide contient le CRUD ; employe.cpp contient le CRUD et la validation. Les autres modèles gardent leur stockage spécialisé.'),
(19,'Répartition modèle / vue','Corrigé','Données et requêtes dans les sources métier/stockage ; widgets et dialogues pour affichage, saisie et interactions.'),
(20,'Partie sécurité','Appliqué','La démonstration de vulnérabilité est lue comme un exemple à éviter.'),
(21,'Injection SQL','Vérifié','Les valeurs utilisateur sont liées à des paramètres ; tests avec apostrophe et texte contenant du SQL.'),
(22,'Exemple d’authentification vulnérable','Non reproduit','Exemple pédagogique. Le stockage des comptes applicatifs et le hachage existants sont conservés.'),
(23,'Exécution de l’authentification','Conservé','Les tests de connexion applicative et de routage des rôles passent.'),
(24,'Expression injectée','Testé','Une recherche contenant une expression de type OR ne contourne pas le filtre ; elle est traitée comme une valeur.'),
(25,'Accès indu dans l’exemple','Non reproduit','Aucune concaténation de saisie utilisateur dans une requête d’authentification.'),
(26,'Explication de la condition toujours vraie','Pris en compte','Séparation texte SQL / paramètres dans les modèles.'),
(27,'prepare, liaison, exec','Corrigé','Les appels SQL directs exec(sql) ont été remplacés dans l’application principale par prepare(sql), puis exec().'),
(28,'Partie fixe et variable','Appliqué','Les valeurs saisies sont liées. Les noms de tables/colonnes dynamiques proviennent de listes internes autorisées, pas des formulaires.'),
(29,'bindValue ou addBindValue','Appliqué','Les deux formes permises par l’atelier sont utilisées. EmployeeQueries privilégie les paramètres positionnels.'),
(30,'Exemple addBindValue','Appliqué','INSERT/UPDATE/DELETE et filtres métiers utilisent les valeurs liées.'),
(31,'Exemple bindValue','Conservé','Les requêtes nommées existantes dans les modèles restent préparées ; aucune valeur n’est injectée dans le texte SQL.'),
(32,'Partie fonctionnalités de base','Appliqué','CRUD métier vérifié en local et via Qt QODBC vers Oracle.'),
(33,'ajouter() dans le modèle','Ajouté','Service::ajouter(), Employe::ajouter(), MedicalRecord::ajouter(). Local et StockRecord utilisent leurs modèles de collection pour conserver la détection des modifications concurrentes.'),
(34,'Bouton → objet → ajouter()','Corrigé','ServiceWidget et GestionEmployes recueillent les valeurs puis appellent l’entité ; aucun SQL dans le gestionnaire du bouton.'),
(35,'Résultat de l’ajout','Vérifié','L’enregistrement apparaît après succès. Le formulaire reste disponible en cas de validation refusée ou d’erreur de stockage.'),
(36,'supprimer() dans le modèle','Ajouté / conservé','Suppression paramétrée pour Service, Employe et MedicalRecord. Les modèles de collections assurent celle des locaux/lots ; les clés étrangères restent protectrices.'),
(37,'Objet modèle dans la vue','Adapté au projet','Les vues emploient leurs objets Service/Employe et leurs modèles existants ; le nom Etmp reste propre à l’exemple du cours.'),
(38,'ID typé et appel supprimer','Appliqué','IDs entiers issus de la sélection ; lot identifié par sa clé texte. Aucune conversion par concaténation SQL.'),
(39,'Résultat de la suppression','Vérifié','Actualisation après succès ; refus explicite quand des enregistrements liés empêchent la suppression.'),
(40,'afficher() et QSqlQueryModel','Ajouté','Service::afficher() prépare la requête, exécute et remplit un QSqlQueryModel avec les titres des colonnes.'),
(41,'Affichage dans le constructeur','Conservé / adapté','ServiceWidget appelle refresh() dans son constructeur. Les cartes/QTableWidget existants utilisent les données du QSqlQueryModel ; les autres modules conservent leurs modèles spécialisés.'),
(42,'Connexion avant fenêtre principale','Vérifié','main.cpp ouvre le Singleton avant AppController::start(), qui crée/affiche les fenêtres applicatives.'),
(43,'Rafraîchir après chaque mutation','Vérifié','Les scénarios de test vérifient les données affichées après création, modification et suppression.'),
(44,'Actualiser après ajout réussi','Appliqué','refresh()/onFiltresChange() seulement après succès du modèle ; notifications ou messages de validation intégrés.'),
(45,'Actualiser après suppression réussie','Appliqué','La sélection et la liste sont mises à jour après succès ; les données restent visibles en cas de refus.'),
(46,'CRUD, métiers et Arduino','Appliqué au périmètre','Ajout, affichage, modification et suppression présents. Métiers/Arduino sont cités comme fonctionnalités avancées ; cette page ne demande pas de nouveau montage Arduino.'),
(47,'Singleton, requêtes préparées, ergonomie','Vérifié / modifié','DatabaseManager::instance() est un Meyers Singleton. Une connexion applicative nommée est partagée. Services utilise maintenant QStackedWidget pour liste et formulaire. La page autorise explicitement une GUI différente de l’exemple.'),
(48,'Réduire dialogues, validation C++, contraintes','Corrigé / vérifié','Formulaires Services intégrés à la page, boîtes de succès Employés retirées, erreurs de saisie conservées dans le formulaire. Validation renforcée dans les modèles. PK/FK/CHECK Oracle vérifiés. Des dialogues spécialisés subsistent pour confirmation, PDF, planning et certains formulaires des autres modules : la consigne demande de minimiser, pas de supprimer tous les dialogues.'),
(49,'Références','Source documentaire','Liens de lecture du cours ; aucune modification du projet imposée sur cette page.'),
(50,'Fin du document','Contexte','Fin des 50 diapositives inspectées. La numérotation utilisée ici est l’ordre réel du fichier, certains numéros imprimés dans le cours étant décalés.')
]
def file_link(path,label):return '<a href="'+escape((root/path).as_uri())+'">'+escape(label)+'</a>'
body=''.join('<tr><td>'+str(n)+'</td><td>'+escape(title)+'</td><td>'+escape(status)+'</td><td>'+escape(detail)+'</td></tr>' for n,title,status,detail in rows)
files=[('src/models/service.cpp','Service : CRUD et QSqlQueryModel'),('src/employees/employe.cpp','Employé : CRUD et validation'),('src/models/employeequeries.cpp','Employés : lectures, statistiques et planning'),('src/models/relationmodel.cpp','Choix des relations'),('src/models/invoicemodel.cpp','Facture incluse dans SERVICES'),('src/stock/stockrecord.cpp','Stock : lecture et validation des lots'),('src/locaux/local.cpp','Local : lecture et validation'),('src/widgets/servicewidget.cpp','Vue Services : formulaire intégré et appels au modèle'),('src/database/databasemanager.cpp','Singleton de connexion'),('tools/check_workshop_architecture.py','Contrôle de séparation modèle–vue'),('artifacts/atelier-crud-review/regression.txt','42 tests réussis, aucun échec, 8 tests optionnels ignorés'),('artifacts/atelier-crud-review/final-targeted-tests.txt','6 passages ciblés réussis : modèles, formulaire, intégration Oracle, interfaces, initialisation et nettoyage'),('artifacts/atelier-crud-review/oracle-final-state.txt','Oracle après tests : 5 tables, 0 anomalie de relation, 0 objet invalide'),('artifacts/atelier-crud-review/deployed-check.txt','Exécutable livré : connexion Qt QODBC confirmée')]
out.write_text('''<!doctype html><html lang="fr"><meta charset="utf-8"><title>ANIWORLD — Application de l’atelier CRUD</title>
<style>body{font:16px/1.55 system-ui,sans-serif;margin:40px auto;max-width:1240px;padding:0 24px;color:#203b43;background:#f5f9fa}h1{font-size:30px}h2{margin-top:32px}table{border-collapse:collapse;background:white;width:100%}th,td{border:1px solid #d6e4e7;padding:12px;vertical-align:top;text-align:left}th{background:#276775;color:white}td:first-child{width:35px}td:nth-child(2){width:230px}td:nth-child(3){width:150px}a{color:#1c6177}.note{background:#e4f0f2;border-left:4px solid #276775;padding:16px}li{margin:6px 0}@media print{body{margin:0;font-size:10pt;background:white}thead{display:table-header-group}tr{break-inside:avoid}}</style>
<h1>ANIWORLD — Application de l’atelier CRUD</h1><p>Vérification du 17 octobre 2026 · Atelier_Crud-architectureQT.pptx · 50 diapositives.</p>
<p class="note">Les règles de l’atelier sont appliquées aux entités ANIWORLD. Les exemples « Etudiant », l’interface pédagogique et le code vulnérable ne sont pas recopiés dans le projet. Les adaptations concrètes sont détaillées ci-dessous ; ce rapport ne prétend pas que le projet est une copie textuelle du PowerPoint.</p>
<h2>Ce qui a changé</h2><ul><li>SQL sorti des vues et déplacé vers les modèles C++.</li><li>CRUD ajouté aux entités Service et Employe, points d’entrée ajoutés à MedicalRecord ; modèles Local et StockRecord complétés.</li><li>Requêtes préparées ; validation côté modèle et messages d’erreur préservant la saisie.</li><li>Formulaire Services intégré à un QStackedWidget ; actualisation vérifiée après mutation.</li><li>Singleton et connexion QODBC conservés ; cinq tables et relations Oracle conservées.</li></ul>
<h2>Fichiers à montrer à l’enseignante</h2><ul>'''+''.join('<li>'+file_link(p,label)+'</li>' for p,label in files)+'''</ul>
<h2>Correspondance page par page</h2><table><thead><tr><th>Page</th><th>Contenu de l’atelier</th><th>Traitement</th><th>Application dans ANIWORLD</th></tr></thead><tbody>'''+body+'''</tbody></table>
<h2>Sauvegarde et données</h2><p>Sources avant refactorisation : backups/before-atelier-20261017/source.zip. Les données existantes ne sont pas supprimées. Les fixtures créées par les tests Oracle sont nettoyées. Aucune table supplémentaire ni migration du schéma n’est nécessaire pour cette refactorisation.</p></html>''',encoding='utf-8')
print(out)
