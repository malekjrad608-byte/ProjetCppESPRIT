#include "oraclecollection.h"
#include <QSqlQuery>
#include <QSqlDatabase>
#include <QSqlError>
#include <QMap>
#include <QSet>
#include <QCryptographicHash>

namespace {
QString table(const QString &name){return name=="stock"?"stock_lots":"locaux";}
QStringList columns(const QString &name){return name=="stock"?
    QStringList{"lot","article","category","quantity","unit","threshold","expiry","id_local"}:
    QStringList{"id","name","type","floor","capacity","occupancy","specialty","out_of_service","cleaning","last_cleaned","dirty_since","id_service"};}
bool allowed(const QString &name){return name=="stock"||name=="locaux";}
bool load(const QString &name,OracleCollection::Rows *rows,QString *error){
    QSqlQuery q(QSqlDatabase::database("aniworld-services"));const auto fields=columns(name);
    if(!(q.prepare("SELECT "+fields.join(',')+" FROM "+table(name)+" ORDER BY "+fields[0]) && q.exec())){*error=q.lastError().text();return false;}
    rows->clear();while(q.next()){QVariantList row;for(int i=0;i<fields.size();++i)row<<q.value(i);*rows<<row;}return true;
}
qint64 version(const OracleCollection::Rows &rows){
    QMap<QString,QVariantList> ordered;for(const auto &row:rows)ordered.insert(row[0].toString(),row);
    QByteArray bytes;for(const auto &row:ordered)for(const auto &value:row){const auto s=value.toString().toUtf8();bytes+=QByteArray::number(s.size())+':'+s;}
    const auto hash=QCryptographicHash::hash(bytes,QCryptographicHash::Sha256);quint64 result=0;
    for(int i=0;i<8;++i)result=(result<<8)|quint8(hash[i]);
    return qint64((result&0x7fffffffffffffffULL)|1);
}
}
namespace OracleCollection {
bool read(const QString &name,Rows *rows,qint64 *revision,QString *error){
    if(!allowed(name)){*error="Collection inconnue.";return false;}
    if(!load(name,rows,error))return false;
    *revision=version(*rows);error->clear();return true;
}
bool save(const QString &name,const Rows &rows,qint64 *revision,QString *error){
    if(!allowed(name)){*error="Collection inconnue.";return false;}
    const auto fields=columns(name);QSet<QString> keys;
    for(const auto &row:rows){
        if(row.size()!=fields.size()||row[0].toString().trimmed().isEmpty()||keys.contains(row[0].toString())){*error="Identifiant vide ou en double.";return false;}
        if(row.last().toInt()<=0){*error=name=="stock"?"Choisissez le local de chaque lot.":"Choisissez le service de chaque local.";return false;}
        keys.insert(row[0].toString());
    }
    auto db=QSqlDatabase::database("aniworld-services");if(!db.transaction()){*error=db.lastError().text();return false;}
    auto fail=[&](QString message){db.rollback();*error=message.section(QChar(0),0,0);return false;};
    QSqlQuery q(db);if(!(q.prepare("LOCK TABLE "+table(name)+" IN EXCLUSIVE MODE WAIT 5") && q.exec()))return fail(q.lastError().text());
    Rows beforeRows;if(!load(name,&beforeRows,error))return fail(*error);
    if(version(beforeRows)!=*revision)return fail("Ces données ont été modifiées par une autre session. Actualisez avant de réessayer.");
    QMap<QString,QVariantList> old;for(const auto &row:beforeRows)old.insert(row[0].toString(),row);
    for(auto it=old.cbegin();it!=old.cend();++it)if(!keys.contains(it.key())){
        q.prepare("DELETE FROM "+table(name)+" WHERE "+fields[0]+"=?");q.addBindValue(it.value()[0]);
        if(!q.exec())return fail(q.lastError().text().contains("02292")?"Ce local contient encore du stock. Réaffectez ses lots avant suppression.":q.lastError().text());
    }
    for(const auto &row:rows){
        const auto before=old.value(row[0].toString());bool changed=before.isEmpty();
        for(int i=0;!changed&&i<fields.size();++i)changed=before[i].toString()!=row[i].toString();
        if(!changed)continue;
        if(before.isEmpty()){
            QStringList marks;for(int i=0;i<fields.size();++i)marks<<"?";
            q.prepare("INSERT INTO "+table(name)+"("+fields.join(',')+") VALUES("+marks.join(',')+")");for(const auto &v:row)q.addBindValue(v);
        }else{
            QStringList assignments;for(int i=1;i<fields.size();++i)assignments<<fields[i]+"=?";
            q.prepare("UPDATE "+table(name)+" SET "+assignments.join(',')+" WHERE "+fields[0]+"=?");
            for(int i=1;i<fields.size();++i)q.addBindValue(row[i]);
            q.addBindValue(row[0]);
        }
        if(!q.exec())return fail(q.lastError().text());
    }
    Rows saved;if(!load(name,&saved,error))return fail(*error);
    if(!db.commit())return fail(db.lastError().text());
    *revision=version(saved);error->clear();return true;
}
}
