#include "service.h"
#include "serviceplanning.h"
#include "../database/oracleconnection.h"
#include "fivetablestore.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlQueryModel>
#include <QSqlRecord>
#include <QScopedPointer>
#include <cmath>
namespace { QVariant nullableId(int id) { return id>0?QVariant(id):QVariant(QMetaType(QMetaType::Int)); } }
QList<Service> Service::afficherListe(QString *error) {
    QList<Service> result;
    QScopedPointer<QSqlQueryModel> model(afficher());
    if(model->lastError().isValid()) { *error=model->lastError().text();return result; }
    while(model->canFetchMore())model->fetchMore();
    error->clear();
    for(int row=0;row<model->rowCount();++row) {
        const auto query=model->record(row);
        Service s;
        s.id=query.value(0).toInt(); s.name=query.value(1).toString();
        s.description=query.value(2).toString(); s.responsible=query.value(3).toString();
        s.category=query.value(4).toString();
        s.dateTime=QDateTime::fromString(query.value(5).toString(),Qt::ISODate);
        s.status=query.value(6).toString(); s.duration=query.value(7).toInt(); s.price=query.value(8).toDouble();
        s.clientName=query.value(9).toString(); s.invoiceNumber=query.value(10).toString();
        s.invoiceDate=QDateTime::fromString(query.value(11).toString(),Qt::ISODate);
        s.localId=query.value(12).toInt(); s.employeeId=query.value(13).toInt(); s.clientId=query.value(14).toInt();
        result.append(s);
    }
    return result;
}
bool Service::enregistrer(bool update, int *insertedId, QString *error) const {
    const Service &s=*this;
    if (s.name.trimmed().isEmpty() || s.name.trimmed().size()>120 || !s.dateTime.isValid()) {
        *error="Vérifiez le nom et la date du service."; return false;
    }
    if (s.clientName.size()>120 || s.description.size()>5000 || !std::isfinite(s.price) || s.price<0 || s.price>99999.99) {
        *error="Vérifiez le client, le détail et le tarif de la prestation."; return false;
    }
    if(s.duration<5 || s.duration>1440 || !QStringList{"Planifié","En cours","Terminé","Annulé"}.contains(s.status) || s.category.trimmed().isEmpty()) {
        *error="Vérifiez la catégorie, le statut et la durée (5 à 1440 minutes).";return false;
    }
    if(s.status!="Annulé" && !ServicePlanning::available(s.employeeId,s.dateTime,ServicePlanning::end(s),update?s.id:0,error))return false;
    if(OracleConnection::isOracle())return FiveTableStore::saveService(s,update,insertedId,error);
    QSqlQuery query(QSqlDatabase::database("aniworld-services"));
    query.prepare(update
        ? "UPDATE services SET name=?,description=?,responsible=?,category=?,dateTime=?,status=?,duration=?,price=?,clientName=?,id_local=?,id_employe=?,id_client=? WHERE id=?"
        : "INSERT INTO services(name,description,responsible,category,dateTime,status,duration,price,clientName,id_local,id_employe,id_client) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");
    query.addBindValue(s.name.trimmed());
    query.addBindValue(s.description.isNull()?QStringLiteral(""):s.description.trimmed());
    query.addBindValue(s.responsible.isNull()?QStringLiteral(""):s.responsible.trimmed());
    query.addBindValue(s.category); query.addBindValue(s.dateTime.toString(Qt::ISODate));
    query.addBindValue(s.status); query.addBindValue(s.duration); query.addBindValue(s.price);
    query.addBindValue(s.clientName.isNull()?QStringLiteral(""):s.clientName.trimmed());
    query.addBindValue(nullableId(s.localId));
    query.addBindValue(nullableId(s.employeeId));
    query.addBindValue(nullableId(s.clientId));
    if(update) query.addBindValue(s.id);
    if(!query.exec()) {
        const auto code=query.lastError().nativeErrorCode();
        *error=code.contains("20041") ? QStringLiteral("Cette facture a déjà été émise ou annulée. Ses informations sont conservées ; créez une nouvelle prestation pour corriger la facturation.") : query.lastError().text();
        if(code.contains("20051"))*error="Affectation refusée : cet employé a déjà un service ou une tâche sur ce créneau. Actualisez le planning et choisissez un autre horaire ou un autre employé.";
        return false;
    }
    if(update && query.numRowsAffected()!=1) { *error="Ce service n'existe plus."; return false; }
    if (!update) *insertedId = int(OracleConnection::insertedId(query,"services"));
    error->clear(); return true;
}
bool Service::ajouter(QString *error) { int inserted=0; if(!enregistrer(false,&inserted,error))return false; id=inserted; return true; }
bool Service::modifier(QString *error) const { int inserted=0; return enregistrer(true,&inserted,error); }
bool Service::supprimer(int id, QString *error) {
    QSqlQuery query(QSqlDatabase::database("aniworld-services")); query.prepare("DELETE FROM services WHERE id=?"); query.addBindValue(id);
    if(!query.exec()) { *error=OracleConnection::isOracle()?FiveTableStore::friendlyError(query.lastError().text()):query.lastError().text(); return false; }
    if(query.numRowsAffected()!=1) { *error="Ce service n'existe plus."; return false; }
    error->clear(); return true;
}

QSqlQueryModel *Service::afficher(QObject *parent) {
    auto *model=new QSqlQueryModel(parent);
    QSqlQuery query(QSqlDatabase::database("aniworld-services"));
    query.prepare(OracleConnection::isOracle()?"SELECT id,name,description,responsible,category,dateTime,status,duration,price,clientName,invoiceNumber,invoiceDate,0,id_employe,0 FROM services ORDER BY dateTime DESC,id DESC":"SELECT id,name,description,responsible,category,dateTime,status,duration,price,clientName,invoiceNumber,invoiceDate,id_local,id_employe,id_client FROM services ORDER BY dateTime DESC,id DESC");
    query.exec();
    model->setQuery(std::move(query));
    const QStringList titles={"ID","Service","Description","Référent","Catégorie","Date / heure","Statut","Durée","Tarif","Client","Facture","Date facture","Local","Employé","Client enregistré"};
    for(int i=0;i<titles.size();++i)model->setHeaderData(i,Qt::Horizontal,titles[i]);
    return model;
}
